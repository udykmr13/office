package Codility;

public class LinkedList {

	public static void main(String[] args) {
		
		
		
	}

}
