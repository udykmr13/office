package Codility;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Triplets {

	static int n;
	
	public static void main(String[] args) {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter size of array : ");
		
		try {
			n = Integer.parseInt(br.readLine());
			System.out.println("Enter the values :");
			int[] A = new int[n];
			
			for(int i=0;i<n;i++)
			{
			A[i] = Integer.parseInt(br.readLine());	
			}
			
			Triplets t= new Triplets();
			
			System.out.println(t.solution(A));
			
		} catch (NumberFormatException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
	public int solution(int A[])
	{
		List<Integer> list = new ArrayList<Integer>();
		int depth=0;
		int count=0;
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				if(A[i]>A[j])
				{
					for(int k=j+1;k<n;k++)
					{
						if(A[j]<A[k])
						{
							int a = A[i]-A[j];
							int b = A[k]-A[j];
							depth = Math.min(a, b);
							System.out.println("Triplet : ("+A[i]+","+A[j]+","+A[k]+")");
							System.out.println("Depth :"+depth);
							list.add(depth);
							count++;
						}
					}	
				}
				
			}
		}
		System.out.println(list);
		System.out.println(count);
		Integer i = Collections.max(list);
		return i;
		
	}
}
