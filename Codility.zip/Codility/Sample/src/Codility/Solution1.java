package Codility;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class Solution1 {

	public static void main(String[] args) {
		
		int[] A=null;
		 BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		 int n;
		try {
			System.out.println("Enter the size of Array : ");
			n = Integer.parseInt(br.readLine());
			 
				A = new int[n];
					try {
						for(int i=0;i<n;i++)
						 {
						System.out.println("Enter the elements :");
						A[i]=Integer.parseInt(br.readLine());
						
						 }
						
						
					} catch (NullPointerException | NumberFormatException | IOException e) {
						
						e.printStackTrace();
					}
			
		} catch (NumberFormatException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();
		}
		 
		

		 Solution sol = new Solution();
			sol.solution(A);
		
		 }
		
	}
	class Solution{
	 public int solution(int[] A) {
		 List<Integer> list1 = new ArrayList<Integer>(A.length);
		for (int i : A) {
			list1.add(Integer.valueOf(i));
		}
		Collections.sort(list1);
		System.out.println(list1);
		 Set<Integer> s = new LinkedHashSet<Integer>(list1); 
		 List<Integer> list = new ArrayList<Integer>(s);
		for (int i = 0; i < list.size(); i++) {
			int a = 1;
				if(list.get(i)>0)
				{
					
					for (int j = i; j < list.size(); j++)
					{	
					if(a==list.get(j))
					{
						a+=1;
						while(j==list.size()-1)
						{
							System.out.println(a);
							break;
						}
					}
					else if(a!=list.get(j))
					{
						System.out.println(a);
						break;
					}
					}break;
					
				}
				else if (list.get(i)==0)
				{
					System.out.println(1);
				}
				else
				{
					while(i==list.size()-1)
					{
						System.out.println(1);
						break;
					}
					a=0;
					if(list.get(i)>0)
					{
						
						for (int j = i; j < list.size(); j++)
						{	
						if(a==list.get(j))
						{
							a+=1;
							while(j==list.size()-1)
							{
								System.out.println(a);
								break;
							}
						}
						else if(a!=list.get(j))
						{
							System.out.println(a);
							break;
						}
						}break;
						
					
				}
			
		}
		
	 }
		return 0;
	    }
	}
	
	

