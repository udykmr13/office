package Codility;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Solution2 {
	
	public static void main(String[] args) {

		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter size of array : ");
		int n;
		try {
			n = Integer.parseInt(br.readLine());
			System.out.println("Enter the values :");
			int[] A = new int[n];
			for(int i=0;i<n;i++)
			{
			A[i] = Integer.parseInt(br.readLine());	
			}
			
			  
			/*  for(int i = 0;i<n;i++)
			 {
				 A[i]=A[n-i+1];
			 }*/
			
			 List<Integer> list = new ArrayList<Integer>(A.length);
				for (int i : A) {
					list.add(Integer.valueOf(i));
				}
				Object[] objects = list.toArray();
				int[] A2 = new int[objects.length];
				for(int i= 0;i<objects.length;i++)
				{
					A2[i]=(int)objects[i];
				}
				System.out.println("Array : "+list);
				System.out.println("Enter times of rotation");
				int k = Integer.parseInt(br.readLine());
				
				System.out.println(list);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
